
#显示界面
print("+-----------------------------+")
print("| 标准体重计算程序   版面1.0  |") 
print("|       作者：？？？？        |")
print("|                             |")
print("|  1. 男性                    |")
print("|  2. 女性                    |")
print("+-----------------------------+")
sex = input("请选择1 男，2女:")
if sex == '1':
    h = input("请输入身高cm:")
    h = float(h)
    w = (h - 80) * 0.7
    print("您的标准体重是:", w, "kg")
elif sex == '2':
    h = input("请输入身高cm:")
    h = float(h)
    w = (h - 70) * 0.6
    print("您的标准体重是:", w, "kg")
else:
    print("选择错误")





