
#判断一个年份是不是润年
#1. 能被4整除，不能被100整除
#2. 能被400整除  1900 2000
year = input("请输入年份:")
year = int(year)

if year % 4 == 0 and year % 100 != 0:
    print(year,'是润年')
elif year % 400 == 0 :
    print(year, '是润年')
else:
    print(year, '是平年')




