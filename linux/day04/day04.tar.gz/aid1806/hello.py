print("Python　你好！")

print("第一个Python程序")

print("*")
print(1000)
print(1000.1)
