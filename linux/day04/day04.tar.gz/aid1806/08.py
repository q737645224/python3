
#显示界面
print("+-----------------------------+")
print("| 标准体重计算程序   版面1.0  |") 
print("|       作者：？？？？        |")
print("|                             |")
print("|  1. 男性                    |")
print("|  2. 女性                    |")
print("+-----------------------------+")

val1 = 0
rate = 0

sex = input("请选择1 男，2女:")
if sex == '1':
    val1 = 80
    rate = 0.7
elif sex == '2':
    val1 = 70
    rate = 0.6
else:
    print("选择错误")

if sex == '1' or sex == '2':
    h = input("请输入身高cm:")
    h = float(h)
    w = (h - val1) * rate
    print("您的标准体重是:", w, "kg")






