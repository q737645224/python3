
#输入4个正整数，显示最小的一个

#1.输入4个正整数a b c d
a = input("请输入整数a:")
a = int(a)

b = input("请输入整数b:")
b = int(b)

c = input("请输入整数c:")
c = int(c)

d = input("请输入整数d:")
d = int(d)
#print(a, b, c, d)

#比较，找出最小的

if a <= b and a <= c and a <= d:
    print("最小的是:", a)


if b <= a and b <= c and b <= d:
    print("最小的是:", b)

if c <= a and c <= b and c <= d:
    print("最小的是:", c)

if d <= a and d <= b and d <= c:
    print("最小的是:", d)















