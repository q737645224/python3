# 计算变长为a和b的长方形周长
#  #开头的叫　注释　

#　定义变长(变a和b)
#a = 100
a = input("请输入长方形边长a:")
# 标准输入函数
#a = int(a)
a = float(a)

b = input("请输入长方形边长b:")
b = float(b)

# 计算周长
c = (a + b) * 2

#　显示周长
print("周长是:", c)


