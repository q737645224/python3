
#输入4个正整数，显示最小的一个

#1.输入4个正整数a b c d
a = input("请输入整数a:")
a = int(a)

b = input("请输入整数b:")
b = int(b)

c = input("请输入整数c:")
c = int(c)

d = input("请输入整数d:")
d = int(d)
#print(a, b, c, d)

#比较，找出最小的

if a <= b:
    min1 = a
else:
    min1 = b   

if c <= d:
    min2 = c
else:
    min2 = d

if min1 <= min2:
    print("最小的是:", min1)
else:
    print("最小的是:", min2)
    
















